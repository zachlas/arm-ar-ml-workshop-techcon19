import pytest
from appium import webdriver

from appium.webdriver.common.multi_action import MultiAction
from appium.webdriver.common.touch_action import TouchAction

import time


def test_swipe_function(init_appium_and_gatord):
	print 'test complete'
	time.sleep(5)
	assert 1==1


def test_swipe_function_fail(init_appium_and_gatord):
	print 'test fail'
	
	'''
	# rename driver and set action object
	appium_driver = init_appium_and_gatord
	action = TouchAction(appium_driver)

	# Scroll up on bottom arrow
	UI_bottom_arrow = appium_driver.find_element_by_accessibility_id('id_bottom_sheet_arrow') # will error out if not found
	swipe = action.press(UI_bottom_arrow).move_to(x=0,y=0).release()
	swipe.perform()

	# Add Threads, with about 2 seconds inbetween clicks
	UI_plus_thread  = appium_driver.find_element_by_accessibility_id('id_thread_add') # will error out if not found
	for i in range(5):
		click_add = action.tap(UI_plus_thread)
		click_add.perform()
		time.sleep(2)

	# Subtract Threads, with about 2 seconds inbetween clicks
	UI_minus_thread = appium_driver.find_element_by_accessibility_id('id_thread_minus') # will error out if not found
	for i in range(5):
		click_remove = action.tap(UI_minus_thread)
		click_remove.perform()
		time.sleep(2)
	'''

	assert 1==2
