import pytest
from appium import webdriver
from gatord_files.gatord_management import *



def pytest_addoption(parser):
	'''
	Add command line option to pytest.

	--aws specifies if the test is being run in AWS Device Farm.
		--aws True   test is run on AWS Device Farm
		anything else or --aws not included means test is NOT run on AWS Device Farm

	--pkg specifies the package name of the android application.
		--pkg org.tensorflow.lite.examples.detection     test package is org.tensorflow.lite.examples.detection
		MUST define pkg on cmdline for test suite to run at all.

	Example cmdline input running locally (not on AWS):
		pytest tests/ --pkg org.tensorflow.lite.examples.detection

	Example cmdline input running on AWS:
		pytest tests/ --aws True --pkg org.tensorflow.lite.examples.detection
	'''
	parser.addoption("--aws", action="store", default="")
	parser.addoption("--pkg", action="store", default="")



@pytest.fixture
def init_appium_and_gatord(request):
	'''
	Initalize functions, called before each test function is run.

	Steps:
		1) Process the cmdline input and set variables, and exit if no package name is specified 
		2) Specify 'finalizer' code, which is run when tearing down each test function. Noting at the top of this function ensures that if something errors in the startup, the teardown code will still run.
		3) Appium driver is initalized, which will connect to the mobile phone
		4) The profiling gatord is installed and set up.
		5) The profiling gatord process is started; it will not start collecting data until the application under test is launched

	'''

	#######
	# 1) Variable Init
	###################
	ON_AWS   = request.config.option.aws
	PKG_NAME = request.config.option.pkg

	if PKG_NAME == "":
		print 'Setup Error: No package name specified. Please include on the command line like this line:'
		print '    pytest tests/ --pkg org.tensorflow.lite.examples.detection'
		assert 0==1

	app_dir = "/data/data/%s/" % PKG_NAME				#'${DEVICEFARM_APP_PATH%/*}'+'/' 		# => issue: No such file or directory
	sd_dir = "/sdcard/"           						#"/data/local/tmp/"


	#######
	# 2) Teardown Code
	###################
	def fin():
		print "Teardown Function"
		gatord_exit_handler(PKG_NAME,app_dir,sd_dir)
	# Add cleanup code, run after test completes or even if setup code fails
	request.addfinalizer(fin)


	#######
	# 3) Appium Setup
	###################
	driver = setupAppium(ON_AWS)


	#######
	# 4) Gatord Setup
	###################
	package_dir = install_gatord(PKG_NAME,app_dir,sd_dir) 							# output should look similar to: ['cache','gatord','configuration.xml']
	package_dir_contents = package_dir[1].replace('\n', ' ').split(' ') 			# split output files and directories which are seperated by a space (on AWS or Linux) or newline (Windows)
	# Check to make sure the package directory has the profiling gatord app and the required config file. If not, exit
	if not all(x in package_dir_contents for x in ['gatord', 'configuration.xml']):
		print 'Error setting up test, package directory does not contain required files.'
		print package_dir
		assert package_dir_contents == 0


	#######
	# 5) Gatord Start
	###################
	start_output = run_gatord_headless(PKG_NAME, 'G72', 120,app_dir,sd_dir)
	print "gatord startup output: \n",start_output


	return driver




def setupAppium(ON_AWS):
	'''
	Appium driver is initalized, which will connect Python to the mobile phone via an Appium server.

	If running locally, ensure your Appium server is started. 
	If running on AWS, ensure the cmdline option (--aws True) is set. 
	'''
	url = 'http://127.0.0.1:4723/wd/hub'
	desired_caps = {}

	# Don't set capabilities when running on AWS, they are set by AWS automatically
	if ON_AWS != 'True': 	
		desired_caps['platformName'] = 'Android'
		desired_caps['deviceName'] = 'Galexy S9'
		desired_caps['app'] = "C:\\Users\\zaclas01\\OneDrive - Arm\\Conferences\\2019-10_TechCon_SanJose\\AR_Workshop\\object_detection_application\\android\\app\\build\\outputs\\apk\\debug\\app-debug.apk"
		#desired_caps['app'] = "C:\\Users\\zaclas01\\OneDrive - Arm\\Conferences\\2019-10_TechCon_SanJose\\AR_Workshop\\Chess\\android-chess-master\\app\\build\\outputs\\apk\\debug\\app-debug.apk"

	driver = webdriver.Remote(url, desired_caps)

	return driver

