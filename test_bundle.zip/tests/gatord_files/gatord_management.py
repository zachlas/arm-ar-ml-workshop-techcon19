import pytest
from appium import webdriver
import sys
import argparse as ap
import math
import os
import re
import shlex
import shutil
import subprocess as sp
import sys
import tarfile
import tempfile
import time

DEBUG_GATORD = False





# Backporting subprocess.run() (from Python 3.5 and newer) to Python 2
def subprocess_run(*popenargs, **kwargs):
    inputt=None
    check=False
    if inputt is not None:
        if 'stdin' in kwargs:
            raise ValueError('stdin and input arguments may not both be used.')
        kwargs['stdin'] = sp.PIPE

    process = sp.Popen(*popenargs, **kwargs)
    try:
        stdout, stderr = process.communicate(input)
    except:
        process.kill()
        process.wait()
        raise
    retcode = process.poll()
    if check and retcode:
        raise sp.CalledProcessError(
            retcode, process.args, output=stdout, stderr=stderr)
    return retcode, stdout, stderr


def subprocess_run_quiet(*popenargs, **kwargs):
    process = sp.Popen(*popenargs, **kwargs)
    return process


def call_adb_quiet(*args):
    """
    Call `adb` to run a command to completion, but ignore output and errors.

    Args:
        *args : List of command line paramaters.
    """
    import subprocess as sp

    command = ["adb"]
    command.extend(args)

    process = subprocess_run_quiet(command)
    return process


def call_adb(*args, **kwargs):
    """
    Call `adb` to run command to completion, and capture output and results.

    Args:
        *args: List of command line paramaters.
        **kwargs: Text: Is output is text, or binary? Shell: Use a shell?

    Returns:
        The contents of stdout.

    Raises:
        CalledProcessError: The subprocess exited with a non-zero error code.
    """
    import subprocess as sp

    commands = ["adb"]
    commands.extend(args)

    text = kwargs.get("text", True)
    shell = kwargs.get("shell", False)

    if shell:
        # Unix shells need a flattened command for shell commands
        if os.name != 'nt':
            quotedCommands = []
            for command in commands:
                if command != ">":
                    command = shlex.quote(command)
                quotedCommands.append(command)
            commands = " ".join(quotedCommands)

    # Note do not use shell=True; arguments are not safely escaped
    #rep = sp.run(commands, check=True, shell=shell, stdout=sp.PIPE, stderr=sp.PIPE, universal_newlines=text)
    rep,stdout,stderr = subprocess_run(commands, stdout=sp.PIPE, stderr=sp.PIPE, universal_newlines=text)

    return rep,stdout,stderr

def clean_gatord(package):
    """
    Cleanup gatord and test process on the device.

    Args:
        package: Name of package under test.
    """
    # Kill any prior instances of gatord
    call_adbq("shell", "pkill", "gatord")
    call_adbq("shell", "run-as", package, "pkill", "gatord")

    # Kill any prior instances of the test application
    call_adbq("shell", "am", "force-stop", package)

    # Remove any data files in both bounce directory and app directory
    sd_dir = "/data/local/tmp/"
    app_dir = "/data/data/%s/" % package
    call_adbq("shell", "rm", "-f", "%sgatord" % sd_dir)
    call_adbq("shell", "rm", "-f", "%sconfiguration.xml" % sd_dir)
    call_adbq("shell", "rm", "-rf", "%s%s.apc" % (sd_dir, package))
    target = "%sgatord" % app_dir
    call_adbq("shell", "run-as", package, "rm", "-f", target)
    target = "%sconfiguration.xml" % app_dir
    call_adbq("shell", "run-as", package, "rm", "-f", target)
    target = "%s%s.apc" % (app_dir, package)
    call_adbq("shell", "run-as", package, "rm", "-rf", target)

    # Disable perf counters
    call_adb("shell", "setprop", "security.perf_harden", "1")


def install_gatord(package,app_dir,sd_dir):
    """
    Install the gatord binary and configuration files.
    They are assumed to already be in the root directory of the sd card: /sdcard/
    Must move to /data/local/tmp first to properly set permissions (doesn't work in sdcard directory)

    Args:
        package: Name of package under test.
        gatord: Path to the gatord binary file on the host.
        configuration: Path to the configuration XML file on the host. This
            may be None for non-headless runs.
    """
    # Setting paths
    path_to_config_files = sd_dir+"gatord_resources/configuration_files/"
    path_to_gatord = sd_dir+"gatord_resources/"



    # Selecting configuration file:
    print('Selecting Streamline configuration file...')
    devices_output = call_adb("devices","-l")

    devices_split_output = devices_output[1].split(' ')
    device_model = None
    for section in devices_split_output:
        if 'model:' in section:
            device_model = section.split(':')[1]
    if device_model == None:
        return 'Error, model number of phone not exported in recognized format. Tried "adb devices -l" and expected "model:xxxxx". Exiting.'

    # Select correct configuration file 
    config_files_output = call_adb("shell","ls",path_to_config_files) 
    config_files = config_files_output[1].replace('\n', ' ').split(' ')         # split output files and directories which are seperated by a space (on AWS or Linux) or newline (Windows)
    selected_config_file = None  #pre-load as none
    for config_file in config_files:
        if device_model in config_file:  # if config_file (named something like 'configuration_Galaxy_S9_____SM_G960U') has the device_model in it (like 'SM_G960U') then use that config file
            selected_config_file = config_file
    if selected_config_file == None:
        return 'Error, no configuration file for the specified phone model of %s. All configuration files: %s.' %(device_model,' '.join(config_files))

    # Install gatord
    print('Installing gatord...')

    # Install gatord
    call_adb("shell","cp",path_to_gatord+"gatord","/data/local/tmp/gatord")
    call_adb("shell", "chmod", "0777", "/data/local/tmp/"+"gatord")
    call_adb("shell", "run-as", package, "cp", "/data/local/tmp/"+"gatord", app_dir)

    # Install gatord counter configuration
    call_adb("shell","cp",path_to_config_files+selected_config_file,"/data/local/tmp/configuration.xml")
    call_adb("shell", "chmod", "0666", "/data/local/tmp/"+"configuration.xml")
    call_adb("shell", "run-as", package, "cp", "/data/local/tmp/"+"configuration.xml", app_dir)
    
    # Enable perf conters
    call_adb("shell", "setprop", "security.perf_harden", "0")

    package_dir_ls = call_adb("shell", "run-as", package, "ls", app_dir)
    #package_dir_ls = call_adb("shell", "run-as", package, "ls", sd_dir)

    return package_dir_ls


def run_gatord_headless(package, gpuName, timeout, app_dir, sd_dir):
    """
    Run gatord for a headless capture session.

    Results are written to disk.

    Args:
        package: Name of package under test.
        gpuName: The Mali GPU name
        timeout: The test scenario capture timeout in seconds.
    """
    print("\nRunning headless test:")
    if not timeout:
        print("    Capture set to wait for process exit")
    else:
        print("    Capture set to stop after %s seconds" % timeout)


    # Get correct name for apc data output
    apcName = "raw_test_data.apc"

    # Run gatord
    out = call_adb_quiet(
        "shell", "run-as", package, app_dir+"gatord",
        #"--mali-type", gpuName,
        "--config-xml", "configuration.xml",
        "--wait-process", package, "--stop-on-exit", "yes",
        "--max-duration", "%u" % timeout, "--output", app_dir+apcName)

    return out

def gatord_exit_handler(package,app_dir,sd_dir):
    """
    Exit handler which will ensure gatord is killed.

    Note that no other cleanup is performed, allowing device failure
    post-mortem analysis to be performed.

    Args:
        package: The package name.
    """
    # Pkilling gatord
    print("\nKilling gatord ...")
    call_adb("shell", "pkill", "gatord")
    call_adb("shell", "run-as", package, "pkill", "gatord")

    
    ######Get files out of phone
    # Exec out files
    #call_adb('exec-out','run-as',package,'tar','c','/data/data/%s/%s.apc' %(package,package),'>','analyzed_output.zip')

    
    # Make storage dir, might exit with note that directory already exists
    storage_dir = sd_dir+"streamline_data/"
    print("\nTransfering data to %s ..." %storage_dir)
    call_adb("shell","mkdir",storage_dir)


    # Tar up .apc file then copy
    #tar = call_adb("shell","run-as", package,"tar","czf","/data/data/%s/streamline_data.tar.gz" %package, "/data/data/%s/%s.apc" %(package,package))
    #print tar

    # Copy data file over, ensuring there is no overwriting
    apcName = "test.apc"
    i = 1
    storage_dir_ls = call_adb("shell", "ls", storage_dir)
    storage_dir_contents = storage_dir_ls[1].replace('\n', ' ').split(' ')     # split output files and directories which are seperated by a space (on AWS or Linux) or newline (Windows)
    while (apcName) in storage_dir_contents:
        apcName = str(i) + "_test.apc"
        i = i+1    
    cp_output = call_adb("shell", "cp", "-r", app_dir+"raw_test_data.apc", storage_dir+apcName)
    print cp_output

    # Remove tard up files
    #call_adb("shell","run-as", package,"rm","-rf","/data/data/%s/%s.tar.gz" %(package,package))
    

def main():
    # Install new gatord files
    print("\nInstalling new gatord files")
    install_gatord('org.tensorflow.lite.examples.detection')

    # Run the test scenario
    run_gatord_headless('org.tensorflow.lite.examples.detection', 'G72', 20)

    # Remove any new files if requested to do so
    pkill_gatord('org.tensorflow.lite.examples.detection')
    return 0


if __name__ == "__main__":
    sys.exit(main())
